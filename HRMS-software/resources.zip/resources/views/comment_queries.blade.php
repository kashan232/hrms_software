<!-- Manager panel side bar comment queries

{{-- <li class="has-menu"><a class="has-arrow ai-icon" href="#" aria-expanded="false">
        <i class="fas fa-graduation-cap"></i>
        <span class="nav-text">Payrol</span>
    </a>
    <ul aria-expanded="false">
        <li><a href="{{ route('manager-create-salary') }}">Create Salary</a></li>
        <li><a href="{{ route('manager-generate-salary') }}">Generate Salary</a></li>
    </ul>
</li> --}}

{{-- <li class="has-menu"><a class="has-arrow ai-icon" href="#" aria-expanded="false">
        <i class="fas fa-bell"></i>
        <span class="nav-text">Revenue</span>
    </a>
    <ul aria-expanded="false">
        <li><a href="{{ route('manager-add-revenue') }}">Add Revenue</a></li>
        <li><a href="{{ route('manager-all-revenue') }}">All Revenue</a></li>
    </ul>
</li> --}} -->

{{-- //HR panel sidebar --}}
{{-- 
<li><a class="has-arrow ai-icon" href="{{ route('project-listing-to-hr') }}" aria-expanded="false">
    <i class="fas fa-briefcase"></i>
    <span class="nav-text">Projects</span>
</a>
</li>
<li><a class="has-arrow ai-icon" href="{{ route('task') }}" aria-expanded="false">
    <i class="fas fa-tasks"></i>
    <span class="nav-text">Add Task</span>
</a>
</li> --}}

